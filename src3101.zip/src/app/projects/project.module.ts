// import { AnimationKeyframesSequenceMetadata } from "@angular/animations";

// export class Project{
// public projectId:number;
// }