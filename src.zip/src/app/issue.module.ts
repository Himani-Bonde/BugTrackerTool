// import { AnimationKeyframesSequenceMetadata } from "@angular/animations";

// import { Project } from "./projects/project.module"

// export class Issue{
//    public issueName:string
//    public issueDescription:string
//    public createdBy:string
//    public createdOn:string
//    public priority:string
//    public severity:string
//    public status:string
//    public projectId:Project | undefined;
//    public assignedTo=0
//     issue=null
// }